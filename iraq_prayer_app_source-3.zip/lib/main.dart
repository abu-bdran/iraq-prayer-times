import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  tzdata.initializeTimeZones();
  await PrayerAlerts.initialize();
  runApp(const IraqPrayerApp());
}

class IraqPrayerApp extends StatelessWidget {
  const IraqPrayerApp({super.key});

  @override
  Widget build(BuildContext context) {
    const green = Color(0xFF0D5C46);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'مواقيت الصلاة في العراق',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: green, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF7F5EF),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(backgroundColor: green, foregroundColor: Colors.white),
      ),
      home: const PrayerHome(),
    );
  }
}

class Governorate {
  final String name;
  final String apiCity;
  const Governorate(this.name, this.apiCity);
}

const governorates = <Governorate>[
  Governorate('بغداد', 'Baghdad'),
  Governorate('البصرة', 'Basra'),
  Governorate('نينوى', 'Mosul'),
  Governorate('أربيل', 'Erbil'),
  Governorate('السليمانية', 'Sulaymaniyah'),
  Governorate('دهوك', 'Duhok'),
  Governorate('كركوك', 'Kirkuk'),
  Governorate('صلاح الدين', 'Tikrit'),
  Governorate('ديالى', 'Baqubah'),
  Governorate('الأنبار', 'Ramadi'),
  Governorate('بابل', 'Hillah'),
  Governorate('كربلاء', 'Karbala'),
  Governorate('النجف', 'Najaf'),
  Governorate('القادسية', 'Diwaniyah'),
  Governorate('واسط', 'Kut'),
  Governorate('ميسان', 'Amarah'),
  Governorate('ذي قار', 'Nasiriyah'),
  Governorate('المثنى', 'Samawah'),
];

class PrayerTime {
  final String name;
  final String time;
  const PrayerTime(this.name, this.time);
}

class PrayerAlerts {
  static final FlutterLocalNotificationsPlugin plugin = FlutterLocalNotificationsPlugin();

  static Future<void> initialize() async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await plugin.initialize(settings);
    await plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
    // Android controls whether notification sounds may bypass silent/DND.
    // Configure this channel in system settings; the app cannot guarantee override on every device.
  }

  static Future<void> schedule(List<PrayerTime> prayers) async {
    await plugin.cancelAll();
    final now = DateTime.now();
    var id = 100;
    for (final p in prayers) {
      final parts = p.time.split(':');
      if (parts.length < 2) continue;
      final hour = int.tryParse(parts[0]);
      final minute = int.tryParse(parts[1]);
      if (hour == null || minute == null) continue;
      var target = DateTime(now.year, now.month, now.day, hour, minute);
      if (!target.isAfter(now)) target = target.add(const Duration(days: 1));
      await plugin.zonedSchedule(
        id++,
        'حان وقت صلاة ${p.name}',
        'الله أكبر، الله أكبر',
        tz.TZDateTime.from(target, tz.local),
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'prayer_times_channel',
            'تنبيهات الصلاة',
            channelDescription: 'تنبيه عند دخول وقت الصلاة. قد يتطلب السماح بالصوت أثناء الصامت من إعدادات Android.',
            importance: Importance.max,
            priority: Priority.max,
            playSound: true,
            // Add android/app/src/main/res/raw/takbeer.mp3 and set
            // sound: RawResourceAndroidNotificationSound('takbeer')
            // after supplying a licensed audio recording.
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: null,
      );
    }
  }
}

class PrayerHome extends StatefulWidget {
  const PrayerHome({super.key});
  @override
  State<PrayerHome> createState() => _PrayerHomeState();
}

class _PrayerHomeState extends State<PrayerHome> {
  Governorate selected = governorates.first;
  bool shia = false;
  bool alertsOn = true;
  bool loading = false;
  String? error;
  String hijri = '';
  String gregorian = '';
  List<PrayerTime> prayers = const [];
  DateTime? updated;

  @override
  void initState() {
    super.initState();
    loadTimes();
  }

  Future<void> loadTimes() async {
    setState(() { loading = true; error = null; });
    try {
      final method = shia ? 7 : 3;
      final uri = Uri.https('api.aladhan.com', '/v1/timingsByCity', {
        'city': selected.apiCity,
        'country': 'Iraq',
        'method': '$method',
        'school': '0',
      });
      final response = await http.get(uri).timeout(const Duration(seconds: 15));
      if (response.statusCode != 200) throw Exception('تعذّر جلب المواقيت');
      final decoded = jsonDecode(response.body) as Map<String, dynamic>;
      if (decoded['code'] != 200) throw Exception('مصدر المواقيت لم يُرجع بيانات صحيحة');
      final data = decoded['data'] as Map<String, dynamic>;
      final timings = data['timings'] as Map<String, dynamic>;
      final date = data['date'] as Map<String, dynamic>;
      final labels = <String, String>{
        'Fajr': 'الفجر', 'Dhuhr': 'الظهر', 'Asr': 'العصر',
        'Maghrib': 'المغرب', 'Isha': 'العشاء',
      };
      final result = labels.entries.map((e) {
        final raw = (timings[e.key] ?? '--:--').toString().split(' ').first;
        return PrayerTime(e.value, raw);
      }).toList();
      if (mounted) {
        setState(() {
          prayers = result;
          hijri = '${date['hijri']?['day'] ?? ''} ${date['hijri']?['month']?['ar'] ?? ''} ${date['hijri']?['year'] ?? ''} هـ';
          gregorian = '${date['gregorian']?['date'] ?? ''} م';
          updated = DateTime.now();
        });
        if (alertsOn) await PrayerAlerts.schedule(result);
      }
    } catch (_) {
      if (mounted) setState(() => error = 'لم نتمكن من تحميل المواقيت. تحقق من الإنترنت ثم أعد المحاولة.');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final next = _nextPrayer();
    return Scaffold(
      appBar: AppBar(
        title: const Text('مواقيت الصلاة', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        actions: [
          IconButton(tooltip: 'تحديث', onPressed: loadTimes, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: loadTimes,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 28),
          children: [
            _heroCard(next),
            const SizedBox(height: 16),
            _settingsCard(),
            const SizedBox(height: 16),
            Row(
              children: [
                const Expanded(child: Text('مواقيت اليوم', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
                if (loading) const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
              ],
            ),
            const SizedBox(height: 10),
            if (error != null)
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: Colors.red.shade50, borderRadius: BorderRadius.circular(14)),
                child: Column(children: [
                  Text(error!, textAlign: TextAlign.center),
                  const SizedBox(height: 8),
                  FilledButton.tonal(onPressed: loadTimes, child: const Text('إعادة المحاولة')),
                ]),
              )
            else if (prayers.isEmpty)
              const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('جارٍ تحميل مواقيت الصلاة...')))
            else
              ...prayers.map((p) => _prayerTile(p, next?.name == p.name)),
            const SizedBox(height: 12),
            Text(
              'المواقيت تُجلب عبر الإنترنت، وقد تختلف عن التوقيت المعتمد محلياً. راجع إعدادات الجهة الدينية في مدينتك.',
              style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _heroCard(PrayerTime? next) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF0D5C46), Color(0xFF123D35)], begin: Alignment.topRight, end: Alignment.bottomLeft),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [BoxShadow(color: Colors.green.withOpacity(.13), blurRadius: 18, offset: const Offset(0, 8))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: const [
          Icon(Icons.mosque, color: Color(0xFFE7C77A), size: 28),
          SizedBox(width: 8),
          Text('العراق • يومك على الصلاة', style: TextStyle(color: Colors.white, fontSize: 14)),
        ]),
        const SizedBox(height: 22),
        Text(selected.name, style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
        const SizedBox(height: 5),
        Text('$hijri   $gregorian', style: const TextStyle(color: Color(0xFFE4E9E5), fontSize: 13)),
        const SizedBox(height: 20),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: Colors.white.withOpacity(.10), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white.withOpacity(.12))),
          child: Row(children: [
            const Icon(Icons.notifications_active_outlined, color: Color(0xFFE7C77A), size: 28),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('الصلاة القادمة', style: TextStyle(color: Color(0xFFD7E4DD), fontSize: 13)),
              Text(next?.name ?? '—', style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
            ])),
            Text(next?.time ?? '--:--', style: const TextStyle(color: Color(0xFFE7C77A), fontSize: 24, fontWeight: FontWeight.bold)),
          ]),
        ),
      ]),
    );
  }

  Widget _settingsCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFE9E5DA))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('إعدادات المواقيت', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        const Text('المحافظة', style: TextStyle(fontSize: 13, color: Colors.black54)),
        const SizedBox(height: 5),
        DropdownButtonFormField<Governorate>(
          value: selected,
          isExpanded: true,
          decoration: const InputDecoration(border: OutlineInputBorder(), contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10)),
          items: governorates.map((g) => DropdownMenuItem(value: g, child: Text(g.name))).toList(),
          onChanged: (g) { if (g != null) { setState(() => selected = g); loadTimes(); } },
        ),
        const SizedBox(height: 12),
        const Text('طريقة الحساب', style: TextStyle(fontSize: 13, color: Colors.black54)),
        const SizedBox(height: 5),
        SegmentedButton<bool>(
          segments: const [
            ButtonSegment(value: false, label: Text('الوقف السني'), icon: Icon(Icons.nights_stay_outlined)),
            ButtonSegment(value: true, label: Text('الوقف الشيعي'), icon: Icon(Icons.brightness_5_outlined)),
          ],
          selected: {shia},
          onSelectionChanged: (s) { setState(() => shia = s.first); loadTimes(); },
        ),
        const SizedBox(height: 10),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('تنبيهات دخول الصلاة'),
          subtitle: const Text('إشعار نصي: الله أكبر، الله أكبر'),
          value: alertsOn,
          onChanged: (v) async {
            setState(() => alertsOn = v);
            if (v && prayers.isNotEmpty) {
              await PrayerAlerts.schedule(prayers);
            } else {
              await PrayerAlerts.plugin.cancelAll();
            }
          },
        ),
      ]),
    );
  }

  Widget _prayerTile(PrayerTime prayer, bool isNext) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: isNext ? const Color(0xFFE5F1EA) : Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: isNext ? const Color(0xFF0D5C46) : const Color(0xFFEAE7DE), width: isNext ? 1.4 : 1),
      ),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: isNext ? const Color(0xFF0D5C46) : const Color(0xFFF1EFE7),
          child: Icon(_iconFor(prayer.name), color: isNext ? Colors.white : const Color(0xFF0D5C46)),
        ),
        title: Text(prayer.name, style: const TextStyle(fontWeight: FontWeight.w600)),
        trailing: Text(prayer.time, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: isNext ? const Color(0xFF0D5C46) : Colors.black87)),
      ),
    );
  }

  IconData _iconFor(String name) {
    switch (name) {
      case 'الفجر': return Icons.nightlight_round;
      case 'الظهر': return Icons.wb_sunny_outlined;
      case 'العصر': return Icons.sunny;
      case 'المغرب': return Icons.wb_twilight;
      default: return Icons.nights_stay_outlined;
    }
  }

  PrayerTime? _nextPrayer() {
    if (prayers.isEmpty) return null;
    final now = TimeOfDay.now();
    final currentMinutes = now.hour * 60 + now.minute;
    for (final p in prayers) {
      final parts = p.time.split(':');
      if (parts.length < 2) continue;
      final h = int.tryParse(parts[0]) ?? 0;
      final m = int.tryParse(parts[1]) ?? 0;
      if (h * 60 + m > currentMinutes) return p;
    }
    return prayers.first;
  }
}
